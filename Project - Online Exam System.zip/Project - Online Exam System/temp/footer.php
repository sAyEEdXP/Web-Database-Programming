


 <section id="bottom">
   <div class="clear"></div>
    <div class="container wow fadeInDown" >
      <div style="padding:0 15px;" class="row">
      <div style="margin-top:30px; color:#FFF;" class="row">
        <div class="container">
          <div class="col-md-12">
            <div class="footer_txt_left">
               <div class="col-md-12 col-sm-6">
                <div class="widget">
                  <h3>about bdjobs</h3>
                  <ul>
                    <li><a href="">Contributors!</a></li>
                    <li><a href="">About</a></li>
                  </ul>
                </div>    
              </div><!--/.col-md-3-->
              
            </div>
            <div class="footer_txt_ri8"><h3>All rights reserved</h3> © 2017-18 LICT_TUP_OFF_H50_BATCH</div>
          </div>
        </div>
      </div>

    </div>
  </section><!--/#bottom-->


  <script src="js/jquery.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="http:js/jquery.isotope.min.js"></script>
  <script src="js/main.js"></script>








</body>
</html>