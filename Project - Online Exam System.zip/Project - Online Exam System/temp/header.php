<body class="homepage">

  <header id="header">
    <div class="top-bar">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="col-md-8">
              <div class="top-number"><p><i class="fa fa-mobile-phone"></i> 01831661534 | ABK Jehad</p></div>
            </div>
            <div class="col-md-4">
              <!--<div class="social">
                <ul class="social-share">
                  <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                  <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                  <li><a href="#"><i class="fa fa-google-plus"></i></a></li> 
                  <li><a href="#"><i class="fa fa-location-arrow"></i></a></li>
                </ul>

              </div>-->
            </div>
          </div>
        </div>
      </div><!--/.container-->
    </div><!--/.top-bar-->

      
    <div class="container">
      <div class="row hdr_pad">
        <div class="logo_area"><a href="/"><img src="logo.jpg" alt="logo" height="60px"></a></div>
        <div class="tp_btn_area">
          <div class="tp_btn_pstn col-md-12">
            <a href="#" data-toggle="modal" data-target="#myModal" class="about_btn">About Us</a>
            <a href="#" data-toggle="modal" data-target="#myModal" class="signin_btn">LogIn</a>
            <a href="#" data-toggle="modal" data-target="#myModal" class="create_btn">Register</a>
            <!-- Trigger the modal with a button -->
            <!-- Modal -->
            <div id="myModal" class="modal fade" role="dialog">
              <div class="modal-dialog">
        </div>
      </div>
    </div>
  </div>
</div>
</div>
      </header><!--/header-->