 <!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Online exam system by LICT TUp 50 Batch">
  <meta name="author" content="">
  <title> LICT TUP OFF 50 BATCH </title>
  
<?php $filepath = realpath(dirname(__FILE__));
echo $filepath;
?>


  <!-- core CSS -->
  <link href="http://localhost:8080/project_online_exam/css/bootstrap.min.css" rel="stylesheet">
  <link href="http://localhost:8080/project_online_exam/css/font-awesome.min.css" rel="stylesheet">
  <link href="http://localhost:8080/project_online_exam/css/animate.min.css" rel="stylesheet">
  <link href="http://localhost:8080/project_online_exam/css/main.css" rel="stylesheet">
 

  

</head>
