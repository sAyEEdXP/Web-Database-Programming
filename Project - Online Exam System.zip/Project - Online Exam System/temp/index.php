<?php include 'head.php' ?>
 <?php include 'header.php' ?>
<div class="col-md-12 main_box_model">
     <img src="pic1.jpg" />                    
</div>
<div class="col-md-12 main_box_model">
    <img src="ad1.jpg" />               
</div>

<?php include 'footer.php' ?>