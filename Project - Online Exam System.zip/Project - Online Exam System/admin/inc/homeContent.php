<div class="col-md-8">
details

</div>