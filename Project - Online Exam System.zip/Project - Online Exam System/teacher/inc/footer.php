<div class="footer-bottom">

		<div class="container">

			<div class="row">

				<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">

					<div class="copyright">

						Copyright © 2017, TESTYOUBD, All rights reserved

					</div>

				</div>

				<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">

					<div class="design">

						 <a href="#">TESTYOUBD </a> |  <a target="_blank" href="<?php echo urlhelper::baseurl();?>">Web Design & Development by Webenlance</a>

					</div>

				</div>

			</div>

		</div>

	</div>