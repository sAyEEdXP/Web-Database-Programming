<?php
define("FD_HOST", "project_online_exam");
define("RE_HOST","http://");
?>