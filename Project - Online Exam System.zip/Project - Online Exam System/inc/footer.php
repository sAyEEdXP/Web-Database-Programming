 </div>
</div>
<!-- Footer -------------------------------- -->
<nav class="navbar-wrapper navbar-inverse navbar-fixed-bottom">
  <div class="container-fluid">
    <p class="navbar-text pull-left">&copy; 2018 by OES. All rights reserved.</p>
    <a href="#" class="btn navbar-btn btn-danger pull-right">Subscribe</a> 
  </div>
</nav>
</body>

</html>