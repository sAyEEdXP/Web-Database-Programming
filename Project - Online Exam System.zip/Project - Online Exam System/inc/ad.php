
<div class="col-md-12">
<img class="col-md-12" src="http://localhost:8080/project_online_exam/img/freead.jpg" alrt>
</div>
